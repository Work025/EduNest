import "./Book4.css"

function Book4() {
    return (
        <div className="book4">
            <div className="book4-name">
                <div className="book4-name-h1">
                    <h1>Book-4</h1>
                </div>
                <div className="book4-filter">
                    <div className="book4-lsn">
                        <h3>Lesson-1</h3>
                        <span>?/10</span>
                        <button>Get start</button>
                    </div>
                </div>
            </div>
            <div className="book4-tests">
                <div className="book4-lesson">
                    <div className="book4-lesson-name">
                        <h1>Question</h1><i class='fa-solid fa-xmark'></i>
                    </div>
                    <div className="book4-lesson-answer">
                        <p></p>
                        <p></p>
                        <p></p>
                        <p></p>
                    </div>
                    <div className="book4-lesson-btn">
                        <button>Answer</button><button><i class='fa-solid fa-arrow-right'></i></button>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Book4;